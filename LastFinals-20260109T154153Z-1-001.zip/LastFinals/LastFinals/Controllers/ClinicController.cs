﻿using Microsoft.AspNetCore.Mvc;
using LastFinals.Data;
using LastFinals.Models;
using MySql.Data.MySqlClient;
using System.Collections.Generic;

namespace LastFinals.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ClinicController : ControllerBase
    {
        private readonly Db _db = new Db();

        [HttpGet("patients")]
        public List<Patient> GetPatients()
        {
            var list = new List<Patient>();
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new MySqlCommand("SELECT * FROM Patients", conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new Patient
                {
                    PatientID = reader.GetInt32("PatientID"),
                    Name = reader.GetString("Name"),
                    Age = reader.GetInt32("Age"),
                    Address = reader.GetString("Address")
                });
            }
            return list;
        }

        [HttpGet("doctors")]
        public List<Doctor> GetDoctors()
        {
            var list = new List<Doctor>();
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new MySqlCommand("SELECT * FROM Doctors", conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new Doctor
                {
                    DoctorID = reader.GetInt32("DoctorID"),
                    Name = reader.GetString("Name"),
                    Specialty = reader.GetString("Specialty")
                });
            }
            return list;
        }

        [HttpGet("prescriptions")]
        public List<Prescription> GetPrescriptions()
        {
            var list = new List<Prescription>();
            using var conn = _db.GetConnection();
            conn.Open();
            string sql = @"
                SELECT p.PrescriptionID, p.Medicine, p.DateIssued,
                       pat.PatientID, pat.Name as PatientName, doc.DoctorID, doc.Name as DoctorName
                FROM Prescriptions p
                JOIN Patients pat ON p.PatientID = pat.PatientID
                JOIN Doctors doc ON p.DoctorID = doc.DoctorID
                ORDER BY p.PrescriptionID DESC";
            using var cmd = new MySqlCommand(sql, conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new Prescription
                {
                    PrescriptionID = reader.GetInt32("PrescriptionID"),
                    Medicine = reader.GetString("Medicine"),
                    DateIssued = reader.GetDateTime("DateIssued"),
                    Patient = new Patient
                    {
                        PatientID = reader.GetInt32("PatientID"),
                        Name = reader.GetString("PatientName")
                    },
                    Doctor = new Doctor
                    {
                        DoctorID = reader.GetInt32("DoctorID"),
                        Name = reader.GetString("DoctorName")
                    }
                });
            }
            return list;
        }

        [HttpPost("add")]
        public IActionResult AddPrescription([FromBody] PrescriptionCreateDto p)
        {
            if (p.PatientID == 0 || p.DoctorID == 0 || string.IsNullOrWhiteSpace(p.Medicine))
                return BadRequest("All fields are required.");

            try
            {
                using var conn = _db.GetConnection();
                conn.Open();

                string checkSql = @"SELECT COUNT(*) FROM Prescriptions 
                            WHERE PatientID=@pid AND DoctorID=@did AND Medicine=@med AND DateIssued=@date";
                using var checkCmd = new MySqlCommand(checkSql, conn);
                checkCmd.Parameters.AddWithValue("@pid", p.PatientID);
                checkCmd.Parameters.AddWithValue("@did", p.DoctorID);
                checkCmd.Parameters.AddWithValue("@med", p.Medicine);
                checkCmd.Parameters.AddWithValue("@date", p.DateIssued.ToString("yyyy-MM-dd"));
                long exists = (long)checkCmd.ExecuteScalar();
                if (exists > 0) return Conflict("Duplicate prescription.");

                string sql = "INSERT INTO Prescriptions (PatientID, DoctorID, Medicine, DateIssued) VALUES (@pid,@did,@med,@date)";
                using var cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@pid", p.PatientID);
                cmd.Parameters.AddWithValue("@did", p.DoctorID);
                cmd.Parameters.AddWithValue("@med", p.Medicine);
                cmd.Parameters.AddWithValue("@date", p.DateIssued.ToString("yyyy-MM-dd"));
                cmd.ExecuteNonQuery();
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpDelete("delete/{id}")]
        public IActionResult DeletePrescription(int id)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new MySqlCommand("DELETE FROM Prescriptions WHERE PrescriptionID=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            return Ok();
        }
    }

    public class PrescriptionCreateDto
    {
        public int PatientID { get; set; }
        public int DoctorID { get; set; }
        public string Medicine { get; set; }
        public DateTime DateIssued { get; set; }
    }
}
