﻿using MySql.Data.MySqlClient;

namespace LastFinals.Data
{
    public class Db
    {
        private readonly string _connectionString = "server=localhost;database=clinic;user=root;password=Finals;";
        public MySqlConnection GetConnection()
        {
            return new MySqlConnection(_connectionString);
        }
    }
}
