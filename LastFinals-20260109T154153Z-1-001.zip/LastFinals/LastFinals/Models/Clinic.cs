﻿using System;

namespace LastFinals.Models
{
    public class Patient
    {
        public int PatientID { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Address { get; set; }
    }

    public class Doctor
    {
        public int DoctorID { get; set; }
        public string Name { get; set; }
        public string Specialty { get; set; }
    }

    public class Prescription
    {
        public int PrescriptionID { get; set; }
        public string Medicine { get; set; }
        public DateTime DateIssued { get; set; }
        public Patient Patient { get; set; }
        public Doctor Doctor { get; set; }
    }
}
