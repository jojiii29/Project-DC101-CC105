﻿document.addEventListener("DOMContentLoaded", () => {
    const patientSelect = document.getElementById("patientSelect");
    const doctorSelect = document.getElementById("doctorSelect");
    const medicineInput = document.getElementById("medicineInput");
    const dateInput = document.getElementById("dateInput");
    const addBtn = document.getElementById("addBtn");
    const prescriptionsList = document.getElementById("prescriptionsList");

    async function fetchPatients() {
        const res = await fetch("/api/clinic/patients");
        const data = await res.json();
        patientSelect.innerHTML = "<option value=''>Select Patient</option>";
        data.forEach(p => {
            const option = document.createElement("option");
            option.value = p.patientID;
            option.textContent = p.name;
            patientSelect.appendChild(option);
        });
    }

    async function fetchDoctors() {
        const res = await fetch("/api/clinic/doctors");
        const data = await res.json();
        doctorSelect.innerHTML = "<option value=''>Select Doctor</option>";
        data.forEach(d => {
            const option = document.createElement("option");
            option.value = d.doctorID;
            option.textContent = d.name;
            doctorSelect.appendChild(option);
        });
    }

    async function fetchPrescriptions() {
        const res = await fetch("/api/clinic/prescriptions");
        const data = await res.json();
        prescriptionsList.innerHTML = `<div class="listview-header">
            <div>Patient</div>
            <div>Doctor</div>
            <div>Medicine</div>
            <div>Date Issued</div>
            <div>Action</div>
        </div>`;
        data.forEach(p => {
            const row = document.createElement("div");
            row.className = "listview-row";
            row.innerHTML = `
                <div>${p.patient.name}</div>
                <div>${p.doctor.name}</div>
                <div>${p.medicine}</div>
                <div>${new Date(p.dateIssued).toLocaleDateString()}</div>
                <div><button onclick="deletePrescription(${p.prescriptionID})">Delete</button></div>`;
            prescriptionsList.appendChild(row);
        });
    }

    addBtn.addEventListener("click", async () => {
        const patientID = Number(patientSelect.value);
        const doctorID = Number(doctorSelect.value);
        const medicine = medicineInput.value.trim();
        const date = dateInput.value;

        if (!patientID || !doctorID || !medicine || !date) {
            alert("All fields are required.");
            return;
        }

        const res = await fetch("/api/clinic/add", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                PatientID: patientID,
                DoctorID: doctorID,
                Medicine: medicine,
                DateIssued: date
            })
        });

        if (res.status === 409) {
            alert("Duplicate prescription.");
            return;
        } else if (!res.ok) {
            const text = await res.text();
            alert("Failed to add: " + text);
            return;
        }

        patientSelect.value = "";
        doctorSelect.value = "";
        medicineInput.value = "";
        dateInput.value = "";

        fetchPrescriptions();
    });

    window.deletePrescription = async (id) => {
        await fetch("/api/clinic/delete/" + id, { method: "DELETE" });
        fetchPrescriptions();
    }

    fetchPatients();
    fetchDoctors();
    fetchPrescriptions();
});
